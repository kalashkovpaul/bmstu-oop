#include "VisibleObject.hpp"

bool VisibleObject::isVisible() const {
    return true;
}