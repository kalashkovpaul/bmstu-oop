#include "InvisibleObject.hpp"

bool InvisibleObject::isVisible() const {
    return false;
}